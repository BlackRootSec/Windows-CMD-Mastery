---
name: Propose a safe example
about: Suggest a harmless CMD/batch example or improvement.
title: "example: "
labels: enhancement
assignees: ''
---

## Learning objective

## Prerequisites and Windows version

## Proposed behavior

## Expected output

## Side effects and cleanup

Confirm that this uses synthetic data, is authorized, and does not involve credential theft, malware, evasion, or unauthorized access.
