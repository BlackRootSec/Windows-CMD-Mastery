---
name: Documentation correction
about: Report a factual error, unclear explanation, or broken internal link.
title: "docs: "
labels: documentation
assignees: ''
---

## Location

[File path and heading]

## What appears incorrect or unclear?

[Describe the issue.]

## Suggested correction and source

[Include volume, chapter, and printed page when relevant. Do not include secrets or private system output.]
