## Summary

## Why is this change useful?

## Source references

- Volume / chapter / printed page, if relevant:

## Validation

- [ ] Ran `python scripts/validate_links.py`
- [ ] CMD and PowerShell syntax are clearly distinguished
- [ ] Commands are labeled for side effects
- [ ] No secrets or personal data are included
- [ ] Technical claims and test status are accurately described
- [ ] Source redistribution / licensing implications were considered
